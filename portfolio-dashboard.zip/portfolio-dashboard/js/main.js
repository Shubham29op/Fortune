let currentCustomerId = null;
let allCustomersData = [];
let dashboardSummaryData = null;

function formatCurrency(amount) {
    if (!amount) return '₹0';
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
    if (numAmount >= 10000000) {
        return '₹' + (numAmount / 10000000).toFixed(2) + ' Cr';
    } else if (numAmount >= 100000) {
        return '₹' + (numAmount / 100000).toFixed(2) + ' L';
    } else {
        return '₹' + numAmount.toLocaleString('en-IN');
    }
}

function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return date.toLocaleDateString('en-IN', options);
}

function formatTimestamp(timestamp) {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const dateStr = date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    const timeStr = date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    return `${dateStr} ${timeStr}`;
}

function getInitials(name) {
    if (!name) return '??';
    const parts = name.split(' ');
    if (parts.length >= 2) {
        return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
}

async function initDashboard() {
    try {
        dashboardSummaryData = await api.getDashboardSummary();
        
        document.getElementById('totalAUM').textContent = formatCurrency(dashboardSummaryData.totalAUM);
        const activeClients = dashboardSummaryData.activeClients || 0;
        document.getElementById('activeClients').textContent = activeClients;
        
        // Update clients badge
        const clientsBadge = document.getElementById('clientsBadge');
        if (clientsBadge) {
            clientsBadge.textContent = activeClients;
        }
        document.getElementById('avgReturns').textContent = (dashboardSummaryData.avgReturns || 0).toFixed(2) + '%';
        document.getElementById('transactionsToday').textContent = dashboardSummaryData.transactionsToday || 0;

        setTimeout(() => {
            initPerformanceChart();
            initAllocationChart();
            initRiskGauges();
            initMonthlyChart();
        }, 100);
        
        // Update asset distribution immediately
        updateAssetDistribution();

        populateTopClientsTable();
        populateRecentTransactionsTable();
    } catch (error) {
        console.error('Error loading dashboard:', error);
        showNotification('Failed to load dashboard data', 'error');
    }
}

function populateTopClientsTable() {
    const tableContainer = document.getElementById('topClientsTable');
    if (!tableContainer || !dashboardSummaryData || !dashboardSummaryData.topClients) return;

    let html = `
        <table>
            <thead>
                <tr>
                    <th>Client</th>
                    <th>Portfolio</th>
                    <th>Returns</th>
                    <th>Assets</th>
                </tr>
            </thead>
            <tbody>
    `;

    dashboardSummaryData.topClients.forEach(client => {
        html += `
            <tr>
                <td>
                    <div class="client-info">
                        <div class="client-avatar">${getInitials(client.name)}</div>
                        <div class="client-details">
                            <div class="client-name">${client.name}</div>
                            <div class="client-id">${client.clientId || ''}</div>
                        </div>
                    </div>
                </td>
                <td style="font-weight: 600;">${formatCurrency(client.portfolioValue)}</td>
                <td class="positive-value">+${(client.totalReturns || 0).toFixed(2)}%</td>
                <td>${client.assetCount || 0}</td>
            </tr>
        `;
    });

    html += '</tbody></table>';
    tableContainer.innerHTML = html;
}

function populateRecentTransactionsTable() {
    const tableContainer = document.getElementById('recentTransactionsTable');
    if (!tableContainer || !dashboardSummaryData || !dashboardSummaryData.recentTransactions) return;

    let html = `
        <table>
            <thead>
                <tr>
                    <th>Client</th>
                    <th>Type</th>
                    <th>Asset</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
    `;

    dashboardSummaryData.recentTransactions.forEach(txn => {
        const statusClass = txn.status ? txn.status.toLowerCase() : 'pending';
        const typeColor = txn.type === 'BUY' ? 'color: #10b981; font-weight: 600;' : 'color: #ef4444; font-weight: 600;';
        
        html += `
            <tr>
                <td>${txn.customerName || ''}</td>
                <td style="${typeColor}">${txn.type || ''}</td>
                <td>${txn.asset || ''}</td>
                <td style="font-weight: 600;">${formatCurrency(txn.amount)}</td>
                <td><span class="status-badge ${statusClass}">${txn.status || 'PENDING'}</span></td>
            </tr>
        `;
    });

    html += '</tbody></table>';
    tableContainer.innerHTML = html;
}

async function initClientsPage() {
    const clientsGrid = document.getElementById('clientsGrid');
    if (!clientsGrid) return;

    try {
        allCustomersData = await api.getAllCustomers();
        let html = '';

        allCustomersData.forEach(client => {
            const gain = client.totalGain || 0;
            const gainClass = gain >= 0 ? 'positive-value' : 'negative-value';
            const riskLevel = client.riskLevel || 'MODERATE';
            const riskColor = riskLevel === 'LOW' ? '#10b981' : riskLevel === 'MODERATE' ? '#f59e0b' : '#ef4444';

            html += `
                <div class="client-card">
                    <div class="client-card-header">
                        <div class="client-card-avatar">${getInitials(client.name)}</div>
                        <div class="client-card-info">
                            <h3>${client.name}</h3>
                            <p>${client.clientId || ''} • ${client.type || ''}</p>
                        </div>
                    </div>
                    <div class="client-card-stats">
                        <div class="stat-item">
                            <div class="stat-item-label">Portfolio Value</div>
                            <div class="stat-item-value">${formatCurrency(client.portfolioValue)}</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-item-label">Returns</div>
                            <div class="stat-item-value positive-value">+${(client.totalReturns || 0).toFixed(2)}%</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-item-label">Total Gain</div>
                            <div class="stat-item-value ${gainClass}">${formatCurrency(gain)}</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-item-label">Risk Level</div>
                            <div class="stat-item-value" style="color: ${riskColor}; font-size: 16px;">${riskLevel}</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-item-label">Assets</div>
                            <div class="stat-item-value">${client.assetCount || 0}</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-item-label">Join Date</div>
                            <div class="stat-item-value" style="font-size: 14px; color: #6b7280;">${formatDate(client.joinDate)}</div>
                        </div>
                    </div>
                </div>
            `;
        });

        clientsGrid.innerHTML = html;
    } catch (error) {
        console.error('Error loading clients:', error);
        showNotification('Failed to load clients', 'error');
    }
}

async function initPortfolioPage() {
    const portfolioTable = document.getElementById('portfolioTable');
    if (!portfolioTable) return;

    if (!currentCustomerId) {
        portfolioTable.innerHTML = '<div style="padding: 40px; text-align: center; color: #6b7280;">Please select a customer from the dropdown above</div>';
        return;
    }

    try {
        const portfolio = await api.getPortfolioByCustomerId(currentCustomerId);

        document.getElementById('totalPortfolioValue').textContent = formatCurrency(portfolio.totalCurrentValue);
        document.getElementById('totalInvested').textContent = formatCurrency(portfolio.totalInvested);
        document.getElementById('totalGains').textContent = formatCurrency(portfolio.totalGain);
        document.getElementById('totalReturns').textContent = (portfolio.totalReturns || 0).toFixed(2) + '% Returns';

        let html = `
            <div style="background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th style="text-align: left; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Asset</th>
                            <th style="text-align: left; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Category</th>
                            <th style="text-align: right; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Quantity</th>
                            <th style="text-align: right; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Avg Price</th>
                            <th style="text-align: right; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Current Price</th>
                            <th style="text-align: right; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Invested</th>
                            <th style="text-align: right; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Current Value</th>
                            <th style="text-align: right; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Returns</th>
                            <th style="text-align: right; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Gain/Loss</th>
                            <th style="text-align: center; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        if (portfolio.holdings && portfolio.holdings.length > 0) {
            portfolio.holdings.forEach((holding) => {
                const returns = holding.returns || 0;
                const gain = holding.gain || 0;
                const returnsClass = returns >= 0 ? 'positive-value' : 'negative-value';
                const gainClass = gain >= 0 ? 'positive-value' : 'negative-value';

                html += `
                    <tr>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; font-weight: 600;">${holding.assetName}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px;">${holding.category}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; text-align: right;">${(holding.quantity || 0).toLocaleString()}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; text-align: right;">₹${(holding.avgPrice || 0).toLocaleString()}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; text-align: right; font-weight: 600;">₹${(holding.currentPrice || 0).toLocaleString()}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; text-align: right;">${formatCurrency(holding.investedAmount)}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; text-align: right; font-weight: 600;">${formatCurrency(holding.currentValue)}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; text-align: right;" class="${returnsClass}">${returns >= 0 ? '+' : ''}${returns.toFixed(2)}%</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; text-align: right; font-weight: 600;" class="${gainClass}">${gain >= 0 ? '+' : ''}${formatCurrency(gain)}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; text-align: center;">
                            <button class="action-btn delete" onclick="removeAsset(${holding.id})" title="Remove Asset">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        } else {
            html += '<tr><td colspan="10" style="padding: 40px; text-align: center; color: #6b7280;">No holdings found</td></tr>';
        }

        html += '</tbody></table></div>';
        portfolioTable.innerHTML = html;
    } catch (error) {
        console.error('Error loading portfolio:', error);
        showNotification('Failed to load portfolio', 'error');
    }
}

async function removeAsset(holdingId) {
    if (confirm('Are you sure you want to remove this asset from the portfolio?')) {
        try {
            await api.removeHolding(holdingId);
            showNotification('Asset removed successfully!', 'success');
            initPortfolioPage();
        } catch (error) {
            console.error('Error removing asset:', error);
            showNotification('Failed to remove asset', 'error');
        }
    }
}

async function addAsset(assetData) {
    if (!currentCustomerId) {
        showNotification('Please select a customer first', 'error');
        return;
    }

    try {
        const holdingData = {
            assetName: assetData.name,
            category: assetData.category,
            quantity: parseFloat(assetData.quantity),
            avgPrice: parseFloat(assetData.avgPrice),
            currentPrice: parseFloat(assetData.currentPrice)
        };

        await api.addHolding(currentCustomerId, holdingData);
        showNotification('Asset added successfully!', 'success');
        
        // Refresh portfolio page
        await initPortfolioPage();
        
        // Refresh dashboard data if on dashboard
        if (document.getElementById('dashboard-page') && !document.getElementById('dashboard-page').classList.contains('hidden')) {
            await initDashboard();
        }
    } catch (error) {
        console.error('Error adding asset:', error);
        const errorMsg = error.message || 'Failed to add asset';
        showNotification(errorMsg, 'error');
    }
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    
    notification.style.cssText = `
        position: fixed;
        top: 90px;
        right: 30px;
        background: ${type === 'success' ? '#10b981' : '#ef4444'};
        color: white;
        padding: 16px 24px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        display: flex;
        align-items: center;
        gap: 12px;
        font-weight: 600;
        z-index: 3000;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function setupClientModal() {
    const modal = document.getElementById('addClientModal');
    const addClientBtn = document.getElementById('addClientBtn');
    const closeModal = document.getElementById('closeClientModal');
    const cancelBtn = document.getElementById('cancelClientBtn');
    const addClientForm = document.getElementById('addClientForm');

    if (addClientBtn) {
        addClientBtn.addEventListener('click', () => {
            modal.classList.add('active');
        });
    }

    if (closeModal) {
        closeModal.addEventListener('click', () => {
            modal.classList.remove('active');
            if (addClientForm) addClientForm.reset();
        });
    }

    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
            modal.classList.remove('active');
            if (addClientForm) addClientForm.reset();
        });
    }

    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
            if (addClientForm) addClientForm.reset();
        }
    });

    if (addClientForm) {
        addClientForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            try {
                const clientData = {
                    name: document.getElementById('clientName').value,
                    clientId: document.getElementById('clientId').value,
                    email: document.getElementById('clientEmail').value || null,
                    type: document.getElementById('clientType').value,
                    riskLevel: document.getElementById('riskLevel').value
                };
                
                await api.createCustomer(clientData);
                showNotification('Client added successfully!', 'success');
                modal.classList.remove('active');
                addClientForm.reset();
                
                // Refresh clients list and dropdown
                await loadCustomersDropdown();
                if (document.getElementById('clients-page') && !document.getElementById('clients-page').classList.contains('hidden')) {
                    await initClientsPage();
                }
            } catch (error) {
                console.error('Error adding client:', error);
                showNotification(error.message || 'Failed to add client', 'error');
            }
        });
    }
}

function setupModal() {
    const modal = document.getElementById('addAssetModal');
    const addAssetBtn = document.getElementById('addAssetBtn');
    const closeModal = document.getElementById('closeModal');
    const cancelBtn = document.getElementById('cancelBtn');
    const addAssetForm = document.getElementById('addAssetForm');

    if (addAssetBtn) {
        addAssetBtn.addEventListener('click', () => {
            if (!currentCustomerId) {
                showNotification('Please select a customer first', 'error');
                return;
            }
            modal.classList.add('active');
        });
    }

    if (closeModal) {
        closeModal.addEventListener('click', () => {
            modal.classList.remove('active');
            if (addAssetForm) addAssetForm.reset();
        });
    }

    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
            modal.classList.remove('active');
            if (addAssetForm) addAssetForm.reset();
        });
    }

    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
            if (addAssetForm) addAssetForm.reset();
        }
    });

    if (addAssetForm) {
        addAssetForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const assetData = {
                name: document.getElementById('assetName').value,
                category: document.getElementById('assetCategory').value,
                quantity: document.getElementById('assetQuantity').value,
                avgPrice: document.getElementById('avgPrice').value,
                currentPrice: document.getElementById('currentPrice').value
            };
            
            addAsset(assetData);
            modal.classList.remove('active');
            addAssetForm.reset();
        });
    }
}

async function initTransactionsPage() {
    const transactionsTable = document.getElementById('transactionsTable');
    if (!transactionsTable) return;

    try {
        const transactions = await api.getAllTransactions();

        let html = `
            <div style="background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th style="text-align: left; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Transaction ID</th>
                            <th style="text-align: left; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Client</th>
                            <th style="text-align: left; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Type</th>
                            <th style="text-align: left; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Asset</th>
                            <th style="text-align: left; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Category</th>
                            <th style="text-align: right; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Quantity</th>
                            <th style="text-align: right; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Price</th>
                            <th style="text-align: right; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Amount</th>
                            <th style="text-align: left; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Status</th>
                            <th style="text-align: left; padding: 12px; font-size: 13px; color: #6b7280; font-weight: 600; border-bottom: 2px solid #e5e7eb;">Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        if (transactions && transactions.length > 0) {
            transactions.forEach(txn => {
                const statusClass = txn.status ? txn.status.toLowerCase() : 'pending';
                const typeColor = txn.type === 'BUY' ? 'color: #10b981; font-weight: 600;' : 'color: #ef4444; font-weight: 600;';

                html += `
                    <tr>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 13px; color: #6b7280;">${txn.transactionId || ''}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px;">${txn.customerName || ''}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; ${typeColor}">${txn.type || ''}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; font-weight: 600;">${txn.asset || ''}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px;">${txn.category || ''}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; text-align: right;">${(txn.quantity || 0).toLocaleString()}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; text-align: right;">₹${(txn.price || 0).toLocaleString()}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; text-align: right; font-weight: 600;">${formatCurrency(txn.amount)}</td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px;"><span class="status-badge ${statusClass}">${txn.status || 'PENDING'}</span></td>
                        <td style="padding: 14px 12px; border-bottom: 1px solid #e5e7eb; font-size: 13px; color: #6b7280;">${formatTimestamp(txn.timestamp)}</td>
                    </tr>
                `;
            });
        } else {
            html += '<tr><td colspan="10" style="padding: 40px; text-align: center; color: #6b7280;">No transactions found</td></tr>';
        }

        html += '</tbody></table></div>';
        transactionsTable.innerHTML = html;
    } catch (error) {
        console.error('Error loading transactions:', error);
        showNotification('Failed to load transactions', 'error');
    }
}

async function loadCustomersDropdown() {
    try {
        allCustomersData = await api.getAllCustomers();
        const selector = document.getElementById('customerSelector');
        if (!selector) return;

        selector.innerHTML = '<option value="">All Customers</option>';
        allCustomersData.forEach(customer => {
            const option = document.createElement('option');
            option.value = customer.id;
            option.textContent = `${customer.name} (${customer.clientId || ''})`;
            selector.appendChild(option);
        });

        // Update clients badge
        const clientsBadge = document.getElementById('clientsBadge');
        if (clientsBadge) {
            clientsBadge.textContent = allCustomersData.length;
        }

        selector.addEventListener('change', (e) => {
            currentCustomerId = e.target.value ? parseInt(e.target.value) : null;
            if (document.getElementById('portfolio-page') && !document.getElementById('portfolio-page').classList.contains('hidden')) {
                initPortfolioPage();
            }
            // Update Sharpe Ratio gauges when customer changes
            if (dashboardSummaryData) {
                initRiskGauges();
            }
        });
    } catch (error) {
        console.error('Error loading customers dropdown:', error);
    }
}

function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page-content');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            
            pages.forEach(page => page.classList.add('hidden'));
            
            const pageId = item.getAttribute('data-page') + '-page';
            const selectedPage = document.getElementById(pageId);
            if (selectedPage) {
                selectedPage.classList.remove('hidden');
                
                if (pageId === 'clients-page') {
                    initClientsPage();
                } else if (pageId === 'portfolio-page') {
                    initPortfolioPage();
                } else if (pageId === 'transactions-page') {
                    initTransactionsPage();
                } else if (pageId === 'analytics-page') {
                    initAnalyticsPage();
                } else if (pageId === 'reports-page') {
                    initReportsPage();
                }
            }
        });
    });
}

function setupMenuToggle() {
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');

    if (menuToggle && sidebar) {
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });

        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 768) {
                if (!sidebar.contains(e.target) && !menuToggle.contains(e.target)) {
                    sidebar.classList.remove('active');
                }
            }
        });
    }
}

function updateCurrentDate() {
    const dateElement = document.getElementById('currentDate');
    if (dateElement) {
        const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
        dateElement.textContent = new Date().toLocaleDateString('en-IN', options);
    }
}

function setupChartFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            console.log('Filter changed to:', btn.getAttribute('data-period'));
        });
    });
}

function updateAssetDistribution() {
    const container = document.getElementById('assetDistributionContent');
    if (!container) return;
    
    if (!dashboardSummaryData || !dashboardSummaryData.assetAllocation) {
        container.innerHTML = '<div style="padding: 20px; text-align: center; color: #6b7280;">Loading asset distribution...</div>';
        return;
    }

    const allocation = dashboardSummaryData.assetAllocation;
    
    let html = '';
    const entries = Object.entries(allocation).sort((a, b) => {
        const valA = parseFloat(a[1]) || 0;
        const valB = parseFloat(b[1]) || 0;
        return valB - valA; // Sort descending
    });
    
    if (entries.length === 0) {
        html = '<div style="padding: 20px; text-align: center; color: #6b7280;">No asset allocation data available</div>';
    } else {
        entries.forEach(([category, percentage]) => {
            const percentageValue = parseFloat(percentage) || 0;
            html += `
                <div class="metric-item">
                    <span class="metric-label">${category}</span>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${percentageValue}%"></div>
                    </div>
                    <span class="metric-value">${percentageValue.toFixed(1)}%</span>
                </div>
            `;
        });
    }
    
    container.innerHTML = html;
}

async function initAnalyticsPage() {
    const analyticsGrid = document.getElementById('analyticsGrid');
    if (!analyticsGrid) return;

    try {
        const summary = await api.getDashboardSummary();
        const customers = await api.getAllCustomers();

        let html = `
            <div class="analytics-card">
                <h3>Portfolio Performance Metrics</h3>
                <div class="analytics-metrics">
                    <div class="analytics-metric">
                        <div class="metric-label">Average Sharpe Ratio</div>
                        <div class="metric-value-large">${(summary.avgSharpeRatio || 0).toFixed(2)}</div>
                        <div class="metric-description">Risk-adjusted return measure</div>
                    </div>
                    <div class="analytics-metric">
                        <div class="metric-label">Average Returns</div>
                        <div class="metric-value-large">${(summary.avgReturns || 0).toFixed(2)}%</div>
                        <div class="metric-description">Average portfolio returns</div>
                    </div>
                    <div class="analytics-metric">
                        <div class="metric-label">Total AUM</div>
                        <div class="metric-value-large">${formatCurrency(summary.totalAUM)}</div>
                        <div class="metric-description">Assets under management</div>
                    </div>
                </div>
            </div>

            <div class="analytics-card">
                <h3>Sharpe Ratio Distribution</h3>
                <div id="sharpeRatioDistribution"></div>
            </div>

            <div class="analytics-card">
                <h3>Top Performers by Sharpe Ratio</h3>
                <div class="analytics-table" id="topSharpeRatioTable"></div>
            </div>
        `;

        analyticsGrid.innerHTML = html;

        // Populate Sharpe Ratio distribution
        const sharpeRatios = customers
            .map(c => c.sharpeRatio || 0)
            .filter(sr => sr > 0);
        
        if (sharpeRatios.length > 0) {
            const excellent = sharpeRatios.filter(sr => sr > 2.0).length;
            const good = sharpeRatios.filter(sr => sr > 1.0 && sr <= 2.0).length;
            const moderate = sharpeRatios.filter(sr => sr > 0.5 && sr <= 1.0).length;
            const poor = sharpeRatios.filter(sr => sr <= 0.5).length;

            document.getElementById('sharpeRatioDistribution').innerHTML = `
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-top: 16px;">
                    <div style="padding: 16px; background: #10b981; color: white; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: 700;">${excellent}</div>
                        <div style="font-size: 12px;">Excellent (&gt;2.0)</div>
                    </div>
                    <div style="padding: 16px; background: #3b82f6; color: white; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: 700;">${good}</div>
                        <div style="font-size: 12px;">Good (1.0-2.0)</div>
                    </div>
                    <div style="padding: 16px; background: #f59e0b; color: white; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: 700;">${moderate}</div>
                        <div style="font-size: 12px;">Moderate (0.5-1.0)</div>
                    </div>
                    <div style="padding: 16px; background: #ef4444; color: white; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: 700;">${poor}</div>
                        <div style="font-size: 12px;">Poor (&lt;0.5)</div>
                    </div>
                </div>
            `;
        }

        // Top performers by Sharpe Ratio
        const topPerformers = customers
            .filter(c => c.sharpeRatio && c.sharpeRatio > 0)
            .sort((a, b) => (b.sharpeRatio || 0).compareTo(a.sharpeRatio || 0))
            .slice(0, 10);

        let tableHtml = `
            <table style="width: 100%; border-collapse: collapse; margin-top: 16px;">
                <thead>
                    <tr>
                        <th style="text-align: left; padding: 12px; border-bottom: 2px solid #e5e7eb;">Client</th>
                        <th style="text-align: right; padding: 12px; border-bottom: 2px solid #e5e7eb;">Sharpe Ratio</th>
                        <th style="text-align: right; padding: 12px; border-bottom: 2px solid #e5e7eb;">Returns</th>
                        <th style="text-align: right; padding: 12px; border-bottom: 2px solid #e5e7eb;">Portfolio Value</th>
                    </tr>
                </thead>
                <tbody>
        `;

        topPerformers.forEach(client => {
            tableHtml += `
                <tr>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">${client.name}</td>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: right; font-weight: 600;">${(client.sharpeRatio || 0).toFixed(2)}</td>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: right;">${(client.totalReturns || 0).toFixed(2)}%</td>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: right;">${formatCurrency(client.portfolioValue)}</td>
                </tr>
            `;
        });

        tableHtml += '</tbody></table>';
        document.getElementById('topSharpeRatioTable').innerHTML = tableHtml;

    } catch (error) {
        console.error('Error loading analytics:', error);
        analyticsGrid.innerHTML = '<div style="padding: 40px; text-align: center; color: #ef4444;">Failed to load analytics data</div>';
    }
}

async function initReportsPage() {
    const reportsContainer = document.getElementById('reportsContainer');
    if (!reportsContainer) return;

    try {
        const summary = await api.getDashboardSummary();
        const customers = await api.getAllCustomers();
        const transactions = await api.getAllTransactions();

        const reportDate = new Date().toLocaleDateString('en-IN', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });

        let html = `
            <div class="report-card">
                <div class="report-header">
                    <h3>Portfolio Performance Report</h3>
                    <div style="color: #6b7280; font-size: 14px;">Generated on ${reportDate}</div>
                </div>
                <div class="report-content">
                    <div class="report-section">
                        <h4>Executive Summary</h4>
                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-top: 16px;">
                            <div>
                                <div style="font-size: 12px; color: #6b7280;">Total AUM</div>
                                <div style="font-size: 20px; font-weight: 700; margin-top: 4px;">${formatCurrency(summary.totalAUM)}</div>
                            </div>
                            <div>
                                <div style="font-size: 12px; color: #6b7280;">Active Clients</div>
                                <div style="font-size: 20px; font-weight: 700; margin-top: 4px;">${summary.activeClients}</div>
                            </div>
                            <div>
                                <div style="font-size: 12px; color: #6b7280;">Average Sharpe Ratio</div>
                                <div style="font-size: 20px; font-weight: 700; margin-top: 4px;">${(summary.avgSharpeRatio || 0).toFixed(2)}</div>
                            </div>
                        </div>
                    </div>
                    <div class="report-section">
                        <h4>Risk Analysis</h4>
                        <div style="margin-top: 16px;">
                            <div style="margin-bottom: 12px;">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                                    <span>Average Returns</span>
                                    <span style="font-weight: 600;">${(summary.avgReturns || 0).toFixed(2)}%</span>
                                </div>
                            </div>
                            <div style="margin-bottom: 12px;">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                                    <span>Average Sharpe Ratio</span>
                                    <span style="font-weight: 600;">${(summary.avgSharpeRatio || 0).toFixed(2)}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="report-section">
                        <h4>Asset Allocation</h4>
                        <div style="margin-top: 16px;">
                            ${Object.entries(summary.assetAllocation || {})
                                .map(([category, percentage]) => `
                                    <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e5e7eb;">
                                        <span>${category}</span>
                                        <span style="font-weight: 600;">${parseFloat(percentage).toFixed(1)}%</span>
                                    </div>
                                `).join('')}
                        </div>
                    </div>
                </div>
            </div>
        `;

        reportsContainer.innerHTML = html;
    } catch (error) {
        console.error('Error loading reports:', error);
        reportsContainer.innerHTML = '<div style="padding: 40px; text-align: center; color: #ef4444;">Failed to load reports</div>';
    }
}

function generateReport() {
    window.print();
}

document.addEventListener('DOMContentLoaded', () => {
    updateCurrentDate();
    setupNavigation();
    setupMenuToggle();
    setupChartFilters();
    setupClientModal();
    setupModal();
    loadCustomersDropdown();
    initDashboard();
    
    setInterval(updateCurrentDate, 60000);
    
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
});

window.addEventListener('resize', () => {
    if (window.innerWidth <= 768) {
        document.getElementById('sidebar').classList.remove('active');
    }
});
