const API_BASE_URL = 'http://localhost:8080/api';

async function fetchAPI(endpoint) {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`API Error fetching ${endpoint}:`, error);
        throw error;
    }
}

async function postAPI(endpoint, data) {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`API Error posting to ${endpoint}:`, error);
        throw error;
    }
}

async function deleteAPI(endpoint) {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'DELETE'
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.status === 204 ? null : await response.json();
    } catch (error) {
        console.error(`API Error deleting ${endpoint}:`, error);
        throw error;
    }
}

const api = {
    getDashboardSummary: () => fetchAPI('/dashboard/summary'),
    getAllCustomers: () => fetchAPI('/customers'),
    getCustomerById: (id) => fetchAPI(`/customers/${id}`),
    createCustomer: (customerData) => postAPI('/customers', customerData),
    getPortfolioByCustomerId: (customerId) => fetchAPI(`/portfolios/customer/${customerId}`),
    addHolding: (customerId, holdingData) => postAPI(`/portfolios/customer/${customerId}/holdings`, holdingData),
    removeHolding: (holdingId) => deleteAPI(`/portfolios/holdings/${holdingId}`),
    getAllTransactions: () => fetchAPI('/transactions'),
    getTransactionsByCustomerId: (customerId) => fetchAPI(`/transactions/customer/${customerId}`)
};
